<!-- Please Note that the GitHub issue tracker is for bug reports. -->
<!-- If you have general questions, please reach out to us via -->
<!-- our other support channels: https://www.highcharts.com/support -->

#### Expected behaviour


#### Actual behaviour
<!-- screenshots welcome! -->

#### Reproduction steps
<!-- Please describe how to reproduce the issue. --> 
<!-- If you can, please include a curl fetch that demonstrates the issue, e.g. -->
<!-- curl -H "Content-Type: application/json" -X POST -d '{"infile":{ <CHART OPTIONS HERE> }' 127.0.0.1:7801 -o mychart.png -->

